import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
public class Main {

//#1
public static String repeat(String s, int n){
        StringBuilder res = new StringBuilder();
        for (var c: s.toCharArray()) {
        res.append(String.valueOf(c).repeat(Math.max(0, n)));
        }
        return res.toString();
        }

//#2
public static int differenceMaxMin(int[]arr){
        int max = Arrays.stream(arr).max().getAsInt();
        int min = Arrays.stream(arr).min().getAsInt();
        return max-min;
        }

//#3
public static boolean isAvgWhole(int[] arrs){
        double avg = Arrays.stream(arrs).average().getAsDouble();
        return avg == Math.rint(avg);
        }

//#4
public static int[] cumulativeSum(int[] a ){
        int b[] = new int[a.length];
        b[0] = a[0];
        for (int i = 1; i < a.length; i++) b[i]=b[i-1]+a[i];
        return  b;
        }

//#5
public static int getDecimalPlaces(String s){
        String[] r = s.split("\\.");
        if (r.length < 2) return 0;
        else return r[1].length();
        }

//#6
public static int Fibonacci(int n){
        if(n == 0)
        return 0;
        else if(n == 1)
        return 1;
        else
        return Fibonacci(n - 1) + Fibonacci(n - 2);
        }

//#7
public static boolean isValid(String adr){
        String pattern = "([0-9]){5}";
        return adr.matches(pattern);
        }

//#8
public static boolean isStrangePair(String a, String b){
        return a.charAt(0) == b.charAt(b.length()-1)
        && a.charAt(a.length()-1) == b.charAt(0);
        }

//#9
public static boolean isPrefix(String s, String prefix){
        String pattern = prefix.replace("-","") +
        ".+";
        return s.matches(pattern);
        }

public static boolean isSuffix(String s, String prefix){
        String pattern = ".+" + prefix.replace("-","");
        return s.matches(pattern);
        }

//#10
        public static String hexLattice(int n) {
                if (n < 1) {
                        return "Invalid!";
                } else if (n == 1) {
                        return "o";
                } else {
                        int sum = 1;
                        int add = 0;

                        int r;
                        for(r = 0; sum < n; ++add) {
                                r = 0;

                                for(int i = sum; i < sum + add; ++i) {
                                        r += 2 * i;
                                }

                                r += sum + add;
                                if (r == n) {
                                        break;
                                }

                                if (r > n) {
                                        return "Invalid!";
                                }

                                ++sum;
                        }

                        if (r != n) {
                                return "Invalid!";
                        } else {
                                StringBuilder sb = new StringBuilder();
                                int d = add;

                                int i;
                                int j;
                                for(i = sum; i <= sum + add; ++i) {
                                        for(j = 0; j < d; ++j) {
                                                sb.append(" ");
                                        }

                                        for(j = 0; j < i; ++j) {
                                                sb.append("o ");
                                        }

                                        sb.append("\n");
                                        --d;
                                }

                                d = sum - add;

                                for(i = sum + add - 1; i >= sum; --i) {
                                        for(j = 0; j < d; ++j) {
                                                sb.append(" ");
                                        }

                                        for(j = 0; j < i; ++j) {
                                                sb.append("o ");
                                        }

                                        sb.append("\n");
                                        ++d;
                                }

                                return sb.toString();
                        }
                }
        }

public static void main(String[] args) {
        System.out.println(repeat("mice",5));
        int arr[]={10,4,1,4,-10,-50,32,21};
        System.out.println(differenceMaxMin(arr));
        int arrs[]={1,3};
        System.out.println(isAvgWhole(arrs));
        int d1[]={1,2,3};
        int e1[]=cumulativeSum(d1);
        for (int i = 0; i < e1.length; i++) System.out.print(e1[i]+ " ");
        System.out.println();
        System.out.println(getDecimalPlaces("43.20"));
        System.out.println(Fibonacci (3));
        System.out.println(isValid("59001"));
        System.out.println(isStrangePair ("ratio", "orator"));
        System.out.println(isPrefix("automation","auto"));
        System.out.println(hexLattice (19));
        System.out.println(hexLattice(1));
        System.out.println(hexLattice(7));
        System.out.println(hexLattice(19));
        System.out.println(hexLattice(21));
        }
        }
